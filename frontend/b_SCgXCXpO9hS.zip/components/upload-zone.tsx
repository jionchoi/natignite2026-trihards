"use client"

import { useCallback, useState } from "react"
import { Upload, X, FileImage, Camera } from "lucide-react"
import Image from "next/image"

interface UploadZoneProps {
  onFileSelect: (file: File) => void
  selectedFile: File | null
  onClear: () => void
  disabled?: boolean
}

export function UploadZone({ onFileSelect, selectedFile, onClear, disabled }: UploadZoneProps) {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files[0]) {
      const file = files[0]
      onFileSelect(file)
      setPreviewUrl(URL.createObjectURL(file))
    }
  }, [onFileSelect])

  const handleClear = useCallback(() => {
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl)
    }
    setPreviewUrl(null)
    onClear()
  }, [previewUrl, onClear])

  if (selectedFile && previewUrl) {
    return (
      <div className="relative w-full frosted-glass rounded-xl p-4 sm:p-6">
        <button
          onClick={handleClear}
          disabled={disabled}
          className="absolute top-2 right-2 sm:top-4 sm:right-4 z-10 p-2 rounded-full bg-background/80 hover:bg-background transition-colors disabled:opacity-50"
          aria-label="Remove uploaded photo"
        >
          <X className="w-4 h-4 sm:w-5 sm:h-5 text-foreground" />
        </button>
        <div className="relative w-full aspect-[4/3] rounded-lg overflow-hidden">
          <Image
            src={previewUrl}
            alt="Uploaded photo of space"
            fill
            className="object-contain"
          />
        </div>
        <div className="mt-3 sm:mt-4 flex items-center gap-2 sm:gap-3">
          <FileImage className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
          <span className="text-xs sm:text-sm text-foreground truncate">{selectedFile.name}</span>
          <span className="text-xs text-muted-foreground ml-auto whitespace-nowrap">
            {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
          </span>
        </div>
      </div>
    )
  }

  return (
    <label
      className={`
        relative flex items-center gap-3 w-full px-4 py-3 sm:px-5 sm:py-4 rounded-xl 
        frosted-glass cursor-pointer transition-all duration-200
        hover:bg-white/[0.08] hover:border-primary/30 active:scale-[0.99]
        ${disabled ? "opacity-50 cursor-not-allowed" : ""}
      `}
    >
      <input
        type="file"
        accept="image/*"
        onChange={handleFileInput}
        disabled={disabled}
        className="sr-only"
        aria-label="Upload photo of your space"
      />
      
      <div className="p-2 rounded-lg bg-primary/10">
        <Camera className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
      </div>
      
      <div className="flex-1 min-w-0">
        <p className="text-sm sm:text-base text-foreground font-medium">
          Upload a photo of your space
        </p>
        <p className="text-xs text-muted-foreground">
          Entrance, restroom, parking, or retail area
        </p>
      </div>

      <Upload className="w-4 h-4 sm:w-5 sm:h-5 text-muted-foreground" />
    </label>
  )
}
